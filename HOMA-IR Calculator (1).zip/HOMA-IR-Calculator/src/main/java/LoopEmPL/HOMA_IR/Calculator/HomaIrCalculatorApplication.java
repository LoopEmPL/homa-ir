package LoopEmPL.HOMA_IR.Calculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomaIrCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomaIrCalculatorApplication.class, args);
	}

}
